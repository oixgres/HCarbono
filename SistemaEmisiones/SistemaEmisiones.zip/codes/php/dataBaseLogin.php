<?php

$host = "localhost";
$user = "omdprofx_guerra-c";
$password="Gue1870";
$bd="omdprofx_guerra-c-ordinario";

$connection = mysqli_connect($host, $user, $password, $bd);

 ?>
