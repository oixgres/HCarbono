<?php

$host = "localhost:3306";
$user = "hcarbono_a1252819";
$password="1094346";
$bd="hcarbono_BD";

$connection = mysqli_connect($host, $user, $password, $bd);
?>
