document.addEventListener('DOMContentLoaded', ()=>{
  $.ajax({
    type: 'GET',
    url: '../php/getUsers.php',

    success: function (response){
      let json = JSON.parse(response);

      console.log(json);
    }
  });
});